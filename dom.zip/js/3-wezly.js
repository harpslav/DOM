

var pierwszyDiv = document.getElementById("par-first");
// console.log(pierwszyDiv);

// pobranie rodzica elementu parentElement
var rodzicPierwszegoDiva = pierwszyDiv.parentElement;
// console.log( rodzicPierwszegoDiva );


// childNodes pobiera wszystkie węzły elementu w tym białe znaki między elementami
// oraz komentarze w kodzie

var dzieciSekcji = rodzicPierwszegoDiva.childNodes;
// pobranie konkretnego "dziecka" za pomocą indeksu jak w tablicach
// console.log(dzieciSekcji[3]);


// children pobiera dzieci elementu tylko te, które są też elementem
var fajniejszeDzieciSekcji = rodzicPierwszegoDiva.children;
// console.log(fajniejszeDzieciSekcji);


// firstChild | firstElementChild - pobiera pierwsze dzieko elementu, przy czym firstChild 
// pobiera także węzeł który może byc #textem, komentarzem lub elementem, a firstElementChild
// tylko węzeł który jest elementem
var pierwszeDzieckoSekcji = rodzicPierwszegoDiva.firstChild;
// console.log(pierwszeDzieckoSekcji);



// lastChild | lastElementChild - pobiera ostatnie dziecko elementu
var ostatnieDzieckoElementu = rodzicPierwszegoDiva.lastElementChild;
// console.log( ostatnieDzieckoElementu );


// rodzeństwo
var link = document.querySelector("#par-first .link");

// previousSibling | previousElementSibling pobiera poprzedni element z tego samego poziomu 
// struktury strony
var rodzenstwoLink = link.previousElementSibling;
// console.log(rodzenstwoLink);

// nextSibling | nextElementSibling pobiera poprzedni element z tego samego poziomu 
// struktury strony
var rodzenstwoLinkNastepny = link.nextElementSibling;
// console.log( rodzenstwoLinkNastepny );

// sprawdzanie nodeType węzłów. nodeType == 1 - element HTML, 3 - białe znaki, 8 - komentarz
rodzicPierwszegoDiva.childNodes.forEach(function(element){
    if( element.nodeType == 1 ) {
        console.log( element );
    }
})




