

// document - cała strona internetowa
console.log(document);

// document.documentElement - pobiera <html>
console.log(document.documentElement);

// document.body - pobiera <body>
console.log(document.body);

// document.head - poobiera <head>
console.log(document.head);

// window
console.log(window);